import sqlite3 as sql

def insertRow(id_usuario, fecha):
    conn = sql.connect("supermercado.db")
    cursor = conn.cursor()
    instruccion = f"INSERT INTO ventas VALUES(NULL,'{id_usuario}','{fecha}')"
    cursor.execute(instruccion)
    conn.commit()
    conn.close()

def insertCliente(correo, passw, usu):
    conn = sql.connect("supermercado.db")
    cursor = conn.cursor()
    instruccion = f"INSERT INTO usuarios VALUES(NULL,2,'{correo}','{passw}','{usu}')"
    cursor.execute(instruccion)
    conn.commit()
    conn.close()

def readProductos():
    conn = sql.connect("supermercado.db")
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM productos"
    cursor.execute(instruccion)
    datos = cursor.fetchall()    
    conn.commit()
    conn.close()
    print(datos)

def readProductos2():
    conn = sql.connect("supermercado.db")
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM productos"
    cursor.execute(instruccion)
    datos = cursor.fetchall()    
    conn.commit()
    conn.close()
    return datos


def search():
    conn = sql.connect("supermercado.db")
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM productos WHERE id_producto=1"
    cursor.execute(instruccion)
    datos = cursor.fetchall()    
    conn.commit()
    conn.close()
    print(datos)

def searchProducto(codigo):
    conn = sql.connect("supermercado.db")
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM productos WHERE id_producto={codigo}"
    cursor.execute(instruccion)
    datos = cursor.fetchall()    
    conn.commit()
    conn.close()
    return datos

def searchUsuariosCompras():
    conn = sql.connect("supermercado.db")
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM usuarios u, ventas v WHERE u.id_usuario=v.id_usuario"
    cursor.execute(instruccion)
    datos = cursor.fetchall()    
    conn.commit()
    conn.close()
    return datos

def Login():
    usuario=input('Ingrese usuario: ')
    password=input('Ingrese contraseña: ')
    conn = sql.connect("supermercado.db")
    cursor = conn.cursor()
    instruccion = f"SELECT * FROM usuarios u, rol r WHERE u.id_rol=r.id_rol and email='{usuario}' and password='{password}'"
    cursor.execute(instruccion)
    datos = cursor.fetchall()    
    conn.commit()
    conn.close()
    return datos

def updateFields():
    conn = sql.connect("supermercado.db")
    cursor = conn.cursor()
    instruccion = f"UPDATE usuarios SET email='sara@gmail.com', password='sara10', usuario='sara10' WHERE id_usuario=2"
    cursor.execute(instruccion)
    conn.commit()
    conn.close()

def updateVentas():
    conn = sql.connect("supermercado.db")
    cursor = conn.cursor()
    instruccion = f"UPDATE ventas SET id_usuario=2"
    cursor.execute(instruccion)
    conn.commit()
    conn.close()

def updateProducto():
    id = int(input('Ingrese el id del producto a modificar: '))
    producto=searchProducto(id)

    nuevonombre=producto[0][1]
    nuevoprecio=str(producto[0][2])
    nuevostock=str(producto[0][3])
    print('1-nombre: '+nuevonombre)
    print('2-precio: '+nuevoprecio)
    print('3-stock: '+nuevostock)
    opcion = int(input('elija la opcion a modificar: '))
    if opcion == 1:
        nuevonombre=input('Ingrese el nuevo nombre: ')
    elif opcion == 2:
        nuevoprecio=input('Ingrese nuevo precio: ')
    elif opcion == 3:
        nuevostock=input('Ingrese nuevo stock: ')
    else:
        input('opcion incorrecta')
 
    conn = sql.connect("supermercado.db")
    cursor = conn.cursor()
    instruccion = f"UPDATE productos SET nombre='{nuevonombre}', precio={nuevoprecio}, stock={nuevostock} WHERE id_producto={id}"
    cursor.execute(instruccion)
    conn.commit()
    conn.close()

def deleteRow():
    conn = sql.connect("supermercado.db")
    cursor = conn.cursor()
    instruccion = f"DELETE FROM productos WHERE id_producto=4"
    cursor.execute(instruccion)
    conn.commit()
    conn.close()
       

if __name__ == "__main__":
    #insertRow(1,'2022-12-20')
    #search()
    #updateFields()
    #deleteRow()
    resu=Login()
    if resu==[]:
        print('usuario y/0 contraseña incorrecta')
    else:
        if resu[0][6]=='administrador':
            opcion='s'
            while opcion=='s':
                print('1-Mostrar productos')
                print('2-Modificar producto')
                print('3-Agregar Cliente')
                print('4-Clientes que realizaron compras por fecha')
                op = int(input('Elija una opcion: '))
                if op==1:
                    productos=readProductos2()
                    print('id nombre precio stock')
                    for producto in productos:
                        print(producto)

                elif op==2:
                    updateProducto()
                    print('producto modificado correctamente')
                elif op==3:
                    email=input('Ingrese el email del nuevo cliente: ')
                    password=input('Ingrese el password: ')
                    usuario=input('Ingrese el nombre de usuario: ')
                    insertCliente(email, password, usuario)
                    print('Cliente agregado correctamente')
                elif op==4:
                    print('Compras realizadas por los usuarios')
                    clientes=searchUsuariosCompras()
                    for cliente in clientes:
                        print(cliente[2]+'   '+cliente[7])
                    #en este caso muestra que el administrador realizo compras
                opcion=input('desea seguir operando[s/n]')
        #si el usuario logueado es un cliente
        else:
            #al cliente solo lo puede agregar un administrador
            vectorproductos=[]
            opcion='s'
            
            while opcion=='s':
                print('usuario cliente')
                print('1-Seleccionar productos')
                print('2-Ver productos seleccionados')
                print('3-Autorizar compra')
                
                
                op = int(input('Elija una opcion: '))
                if op==1:
                  productos=readProductos2()
                #print(productos)
                  print('id nombre precio stock')
                  for producto in productos:
                    print(producto)
                  resp='s'
                         
                  while resp=='s':
                   vectorele=[]
                   id=int(input('Ingrese el id del producto a seleccionar: '))
                   cant=int(input('Ingrese la cantidad a adquirir'))
                   precio=productos[id][2]
                   vectorele.append(id)
                   vectorele.append(precio)
                   vectorele.append(cant)
                   vectorproductos.append(vectorele)
                   resp=input('desea agregar otro producto?[s/n]')
             #print(vectorele)
                elif op==2:
                    print('Elementos seleccionados')
                    print(vectorproductos)
               
                opcion=input('desea seguir operando[s/n]')
    