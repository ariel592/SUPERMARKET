import sys
from PyQt5 import QtWidgets, QtSql, uic #carga intefaz grafica
import sqlite3
from PyQt5.uic import loadUi
import vistaAdmin
import vistaCliente

class Login(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi("ingresar.ui", self)
        self.admin=vistaAdmin.vistaAdmin()
        self.cliente=vistaCliente.vistaCliente()
        # self.db=supermercado.conexion_db()
        # conn = sqlite3.connect('supermercado.db')
        # self.cursor  =conn.cursor()
       
        self.openDB()
        self.setupUiComponents()

    def setupUiComponents(self):
        self.pushButton.clicked.connect(self.loginfunction)
    def openDB(self):
        self.db = QtSql.QSqlDatabase.addDatabase("QSQLITE")
        self.db.setDatabaseName("supermercado.db")
        if not self.db.open():
            print("error")
        self.query = QtSql.QSqlQuery()
        print('fin')

    def loginfunction(self):
        usuario=self.usuario.text()
        password = self.password.text()
        print(password,usuario)

        self.query.exec_("SELECT * FROM Usuarios as U INNER JOIN Rol R ON U.id_rol=R.id_rol where email = '%s' and password='%s';"%(usuario, password))
        self.query.first()
        print(self.query.value("email"))
        if self.query.value("email") != None and self.query.value("password")!= None:
            print("se ingreso exitosamente")
            if self.query.value('nombre')=='administrador':
                self.admin.show()
            else:
                self.cliente.show()

        else:
            print("error al ingresar")
            self.usuario.clear()
            self.password.clear()
       
        

        
def main():
    app = QtWidgets.QApplication(sys.argv)
    
    form = Login()
    form.show()
    app.exec_()

if __name__ == '__main__':
    main()